<?php echo e($slot); ?>

<?php /**PATH C:\Users\DELL\Desktop\room-color\whatsap-business\whatsapp-crm-backend\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>